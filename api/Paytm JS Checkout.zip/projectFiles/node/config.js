
var MID = "uqaqor71832119145372";
var MKEY = "7bF7Q9TJpJ43RJeD";

var ENV= 'securegw-stage.paytm.in';
var WEBSITE= 'WEBSTAGING';

exports.MID = MID;
exports.MKEY = MKEY;
exports.ENV = ENV;
exports.WEBSITE = WEBSITE;